

import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";

// Initialize the DynamoDB client
const dynamodbClient = new DynamoDBClient({ region: "ap-southeast-1" });
export const handler = async (event) => { 
  try {
    // Perform a scan on the table
    const params = {
      TableName: event.tableName,
    };

    const command = new ScanCommand(params);
    const response = await dynamodbClient.send(command);
    console.log(response)
    // Unmarshall each item in the response to convert from DynamoDB JSON format
    const items = response.Items.map((item) => unmarshall(item));

    console.log("Unmarshalled Items:", JSON.stringify(items));
    return items;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
};