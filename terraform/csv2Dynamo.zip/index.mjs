import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { BatchWriteCommand } from "@aws-sdk/lib-dynamodb";
import { parse } from "csv-parse/sync";

const client = new DynamoDBClient({});

export const handler = async (event) => {
  console.log(event)
  try {
    // Decode the base64-encoded CSV string
    const base64String = event.data // Assuming the base64 string is sent in the body
    const csvString = Buffer.from(base64String, "base64").toString("utf-8");

    // Parse the CSV data, skipping the first row (column names)
    const records = parse(csvString, { columns: true, skip_empty_lines: true });
    console.log(records)
    // Prepare batch write requests for DynamoDB
    const tableName = event.tableName;
    const writeRequests = records.map((record) => ({
      PutRequest: {
        Item: {
          phoneNumber: record.phoneNumber,
          name: record.name,
        },
      },
    }));

    // Batch write to DynamoDB
    const BATCH_SIZE = 25; // DynamoDB batch write limit
    for (let i = 0; i < writeRequests.length; i += BATCH_SIZE) {
      const batch = writeRequests.slice(i, i + BATCH_SIZE);
      const params = {
        RequestItems: {
          [tableName]: batch,
        },
      };

      const command = new BatchWriteCommand(params);
      await client.send(command);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Data imported successfully" }),
    };
  } catch (error) {
    console.error("Error importing data:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error importing data", error: error.message }),
    };
  }
};
