import { SchedulerClient, CreateScheduleCommand, UpdateScheduleCommand } from "@aws-sdk/client-scheduler"; // ES Modules import
const client = new SchedulerClient({region: "ap-southeast-1"});

export const handler = async (event) => {
  let response;
  switch (event.action) {
    case "create":
      const createInput = { // CreateScheduleInput
        Name: event.campaign, // required
        ScheduleExpression: `cron(0/3 ${event.startTime}-${event.endTime} ? * ${event.days} ${event.year})`, // required
        Description: `Schedule for ${event.campaign}`,
        ScheduleExpressionTimezone: "Asia/Singapore",
        State: event.state,
        FlexibleTimeWindow: { Mode: "OFF" },
        Target: {
          Arn: "arn:aws:lambda:ap-southeast-1:117134819170:function:outbound", // Replace with target Lambda ARN
          RoleArn: "arn:aws:iam::117134819170:role/RoleForMakeCampaign", // Replace with IAM role ARN
          Input: JSON.stringify({"campaign":`${event.campaign}`}), // Optional payload
          RetryPolicy: {
            MaximumRetryAttempts: 0, // Explicitly disable retries
            MaximumEventAgeInSeconds: 60 // Minimum required value (inactive when retries=0)
          }
        },
        ActionAfterCompletion: "DELETE"
      };
      const createCommand = new CreateScheduleCommand(createInput);
      const createResponse = await client.send(createCommand);
      response = {
        statusCode: 200,
        body: JSON.stringify(createResponse),
      };
      break;
    case "update": 
    const updateInput = { // CreateScheduleInput
      Name: event.campaign, // required
      ScheduleExpression: `cron(0/3 ${event.startTime}-${event.endTime} ? * ${event.days} ${event.year})`, // required
      Description: `Schedule for ${event.campaign}`,
      StartDate: new Date(event.startDate), // Schedule activation time
      EndDate: new Date(event.endDate), // Schedule expiration time
      ScheduleExpressionTimezone: "Asia/Singapore",
      State: event.state,
      FlexibleTimeWindow: { Mode: "OFF" },
      Target: {
        Arn: "arn:aws:lambda:ap-southeast-1:117134819170:function:outbound", // Replace with target Lambda ARN
        RoleArn: "arn:aws:iam::117134819170:role/RoleForMakeCampaign", // Replace with IAM role ARN
        Input: JSON.stringify({"campaign":`${event.campaign}`}), // Optional payload
        RetryPolicy: {
          MaximumRetryAttempts: 0, // Explicitly disable retries
          MaximumEventAgeInSeconds: 60 // Minimum required value (inactive when retries=0)
        }
      },
      ActionAfterCompletion: "DELETE"
    };
    const updateCommand = new UpdateScheduleCommand(updateInput);
    const updateResponse = await client.send(updateCommand);
    response = {
      statusCode: 200,
      body: JSON.stringify(updateResponse),
    };
    break;
    default:
      response = {
        statusCode: 200,
        body: "Nothing to do",
      };
      break;
  }
  
  return response;
};