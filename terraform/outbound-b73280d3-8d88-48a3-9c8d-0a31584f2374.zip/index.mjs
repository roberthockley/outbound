import { DynamoDBClient, ScanCommand, QueryCommand } from "@aws-sdk/client-dynamodb";
import { ConnectClient, StartOutboundVoiceContactCommand } from "@aws-sdk/client-connect";
import { unmarshall } from "@aws-sdk/util-dynamodb";

const dynamoClient = new DynamoDBClient({ region: "ap-southeast-1" });
const connectClient = new ConnectClient({ region: "ap-southeast-1" });

export const handler = async (event) => {

  const dynamoCampaignInput = {
    TableName: "OutboundRules",
    Select: "ALL_ATTRIBUTES",
    KeyConditionExpression: "#campaign = :campaign",
    ExpressionAttributeNames: {
      "#campaign": "campaign"  // Replace with actual key name
    },
    ExpressionAttributeValues: {
      ":campaign": { S: `${event.campaign}` }  // Replace with actual value
    }
  }
  const dynamoCampaignCommand = new QueryCommand(dynamoCampaignInput);
  const dynamoCampaignResponse = await dynamoClient.send(dynamoCampaignCommand);
  const rulesToUse = dynamoCampaignResponse.Items?.map(item => unmarshall(item)) || [];
  const rules = rulesToUse[0]
  console.log(rules)


    // 1. Optimized Scan Parameters
    const dynamoInput = {
      TableName: `${event.campaign}-Campaign`,
      Limit: 20,
      FilterExpression: "attribute_not_exists(#attempt) OR #attempt <> :attemptValue",
      ExpressionAttributeNames: {
        "#attempt": "attempt" // Required for attribute name safety
      },
      ExpressionAttributeValues: {
        ":attemptValue": { S: "true" } // String comparison
      }
    };
  
    try {
      // 2. Efficient Scan Execution
      const { Items } = await dynamoClient.send(new ScanCommand(dynamoInput));
      const records = Items?.map(item => unmarshall(item)) || [];
  
      // 3. Parallel Processing (if safe for your use case)
      const contactPromises = records.map(async (record) => {
        if (!record.phoneNumber) {
          console.warn("Skipping invalid record:", record);
          return;
        }
  
        const connectInput = {
          DestinationPhoneNumber: "+61730719655",
          ContactFlowId: "8b9589f3-3f8c-4328-8cd2-4c07d7c52c69",
          InstanceId: "fd415d45-5ce7-4b93-996e-d2307380bda0",
          SourcePhoneNumber: "+16467010832",
          QueueId: "1c590b59-14df-480e-ad1b-4c6aabd160be",
          Attributes: {
            campaign: "Sales",
            number: normalizePhone(record.phoneNumber)
          }
        };
  
        try {
          const { ContactId } = await connectClient.send(
            new StartOutboundVoiceContactCommand(connectInput)
          );
          console.log("Call initiated to", connectInput.DestinationPhoneNumber, "Contact ID:", ContactId);
        } catch (error) {
          console.error("Connect error for", connectInput.DestinationPhoneNumber, ":", error);
        }
      });
  
      await Promise.allSettled(contactPromises);
      return { processed: records.length };
  
    } catch (error) {
      console.error("Fatal error:", error);
      throw new Error("Campaign processing failed");
    }
  };
  
  // 4. Phone Number Normalization Utility
  const normalizePhone = (number) => {
    const cleanNumber = String(number).replace(/\D+/g, '');
    return `+${cleanNumber}`.replace(/^(\+{2,})/, '+');
};
